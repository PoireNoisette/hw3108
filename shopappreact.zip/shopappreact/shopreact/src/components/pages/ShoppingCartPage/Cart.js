const cart = [
    {
        id: 1,
        title: "Summer book",
        price: 109.95,
        image: "https://www.elefant.ro/cdn-cgi/image/fit=scale-down,format=auto,width=1000/https://cdn.elefant.ro/is/product-images/cartero/53c5f4ff/dbfc/434f/896e/5e7732839e8d/53c5f4ff-dbfc-434f-896e-5e7732839e8d_1.jpg",
        pieces: 3,
    },
]