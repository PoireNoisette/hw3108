function ShoppingCart() {

    return (
        <div>
            You want to buy
            1 vegan book
            1 red book
        </div>
    )
}

export default ShoppingCart;