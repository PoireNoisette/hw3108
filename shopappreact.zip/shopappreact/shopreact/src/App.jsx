import './App.css'
import Layout from './components/Layout/Layout'
import BioBooksPage from './components/pages/BioBooksPage/BioBooks'
import ShoppingCart from './components/pages/ShoppingCartPage/ShoppingCart'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from 'react'

function App() {

  return (
    <BrowserRouter>
      <Layout intemsCount={0}>
        <Routes>
          <Route path="/booklist" element={<BioBooksPage />} />
          <Route path="/shopcart" element={<ShoppingCart />} />
        </Routes>
      </Layout >
    </BrowserRouter>
  )
}

export default App
